import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

    loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;

    constructor(
      private formBuilder: FormBuilder,
      private route: ActivatedRoute,
      private router: Router,
  ) {}
  
  ngOnInit() {
      this.loginForm = this.formBuilder.group({
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(8)]],
      });
  }
  get f() { return this.loginForm.controls; }

  doLogin() {
      this.submitted = true;
      if (this.loginForm.invalid) {
          return;
      }else{
        this.router.navigate(['user'], {
          state: {  }
        });
      }
  }
  doRegister(){
    this.router.navigate(['register'], {
      state: {  }
    });
  }
}
