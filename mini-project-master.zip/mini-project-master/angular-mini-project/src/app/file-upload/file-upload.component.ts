import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {
files:any;
loading = false;
  constructor( private route: ActivatedRoute,
    private router: Router,) { }

  ngOnInit(): void {
  }
  public fileUploader(event,flag) {
    const elem = event.target;
    this.files=event.target.files;
    if (elem.files.length > 0) {
        console.log(elem.files[0]);
    }
}
onSubmit() {
  if (this.files==undefined || this.files.length < 0) {
    alert('Any one file is Mandatory');
      return;
      } else{
          this.router.navigate(['user'], {
              state: {  }
            });
      }       
  }
}
