﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { validate } from 'json-schema';


@Component({
    selector: 'app-user-register',
    templateUrl: './register.component.html',
  })
export class RegisterComponent implements OnInit {
    registerForm: FormGroup;
    loading = false;
    submitted = false;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
    ) {
        
    }

    ngOnInit() {
        console.log('asdas');
        this.registerForm = this.formBuilder.group({
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            email: ['', [Validators.required, Validators.email]],
            mobile:['',[Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
            gender:['Male',Validators.required],
            address:['',Validators.required],
            password: ['', [Validators.required, Validators.minLength(8)]],
            confirmPassword: ['', Validators.required],
        },{
                validator: this.mustMatch('password', 'confirmPassword')
        });
    }

    get f() { return this.registerForm.controls; }

    onSubmit() {
        this.submitted = true;
        if (this.registerForm.invalid) {
            return;
            } else{
                this.router.navigate(['fileupload'], {
                    state: {  }
                  });
            }       
        }

  mustMatch(controlName: string, matchingControlName: string) {
                return (formGroup: FormGroup) => {
                    const control = formGroup.controls[controlName];
                    const matchingControl = formGroup.controls[matchingControlName];
                    if (matchingControl.errors && !matchingControl.errors.mustMatch) {
                        return;
                    }
                    if (control.value !== matchingControl.value) {
                        matchingControl.setErrors({ mustMatch: true });
                    } else {
                        matchingControl.setErrors(null);
                    }
                }
            }
}
