import { Component, OnInit, AfterViewChecked } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit,AfterViewChecked {
users:any;
  constructor(private httpClient: HttpClient) { }
  ngOnInit(): void {
    this.displayUserDetails();
  }

  displayUserDetails(){
    console.log('test');
  this.httpClient.get("assets/userinfo/users.json").subscribe(data =>{
    console.log(data);
    this.users = data;
  })
}
ngAfterViewChecked(): void {
  
}
}
